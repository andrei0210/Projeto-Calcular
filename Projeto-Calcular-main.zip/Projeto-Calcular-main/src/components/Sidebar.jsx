export default function Sidebar() {
    return <div className="sidebar"></div>;
  }